from enum import Enum

class Format(Enum):
    FTF = "Очный"
    DIST = "Дистанционный"