from enum import Enum

class Type(Enum):
    LECTURE = "lecture"
    PRACTICE = "practice"
    LAB = "lab"