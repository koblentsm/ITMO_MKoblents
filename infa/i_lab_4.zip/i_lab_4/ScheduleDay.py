class ScheduleDay():

    def __init__(self, name: str):
        self.name = name
        self.classes = []

    def add_subject(self, subject):
        self.classes.append(subject)    

