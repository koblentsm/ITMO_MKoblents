from enum import Enum

class Address(Enum):
    KRON = "Кронверкский пр., д.49, лит. А"
    LOMO = "ул.Ломоносова, д.9, лит. М "
    NAN = ""