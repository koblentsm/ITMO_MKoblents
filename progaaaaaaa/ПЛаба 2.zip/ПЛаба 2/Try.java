import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Battle;
import pokemons.*;

class Try{
    public static void main(String args[]){
        Battle b = new Battle();
        Pokemon p1 = new Pokemon("1", 1);
        Pokemon p2 = new Pokemon("2", 1);
        Spiritomb p3 = new Spiritomb("3", 1);
        b.addAlly(p1);
        b.addFoe(p2);
        b.addAlly(p3);
        b.go();
    }
}