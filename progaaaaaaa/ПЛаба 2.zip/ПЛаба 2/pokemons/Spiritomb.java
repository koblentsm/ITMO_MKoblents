import ru.ifmo.se.pokemon.*;

class Spiritomb extends Pokemon{

    public Spiritomb(){
        // this.setType(Type.GHOST, Type.DARK);
        // this.setStats(50.0, 92.0, 108.0, 98.0, 108.0, 35.0);
    }

}
