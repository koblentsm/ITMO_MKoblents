class Sewaddle extends Pokemon{
    public Sewaddle(){
        // this.setType(Type.BUG, Type.GRASS);
        // this.setStats(45.0, 53.0, 70.0, 40.0, 60.0, 42.0);
    }
}