class Lycanroc extends Rockruff{
    public Lycanroc(){
        // this.addType(Type.ROCK);
        // this.setStats(75.0, 115.0, 65.0, 55.0, 65.0, 112.0);
    }
}