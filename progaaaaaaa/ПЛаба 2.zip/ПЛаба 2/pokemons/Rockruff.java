class Rockruff extends Pokemon{
    public Rockruff(){
        // this.addType(Type.ROCK);
        // this.setStats(45.0, 65.0, 40.0, 30.0, 40.0, 60.0);
    }
}