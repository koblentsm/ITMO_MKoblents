class Leavanny extends Swadloon{
    public Leavanny(){
        // this.setType(Type.BUG, Type.GRASS);
        // this.setStats(75.0, 103.0, 80.0, 70.0, 80.0, 92.0);
    }
}