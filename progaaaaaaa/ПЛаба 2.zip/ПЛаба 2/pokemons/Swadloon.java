class Swadloon extends Sewaddle{
    public Swadloon(){
    //    this.setType(Type.BUG, Type.GRASS);
    //    this.setStats(55.0, 63.0, 90.0, 50.0, 80.0, 42.0);
    }
}